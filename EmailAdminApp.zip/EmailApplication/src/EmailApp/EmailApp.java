package EmailApp;

public class EmailApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Email em1 = new Email("John","Smith");
		
		System.out.println(em1.showInfo())
;		//em1.setAlternateEmail("Spencerhenegar@gmail.com");
		//System.out.println(em1.getAlternateEmail());
		
	}

	 

}
